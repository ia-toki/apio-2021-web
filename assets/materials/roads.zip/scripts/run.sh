#!/bin/bash

set -euo pipefail

bash "${SANDBOX}/run.sh" "$@"

