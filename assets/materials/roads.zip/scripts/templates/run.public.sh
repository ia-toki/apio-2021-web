#!/bin/bash

sandbox=$(dirname "$0")

"${sandbox}/exec.sh" "$@"
