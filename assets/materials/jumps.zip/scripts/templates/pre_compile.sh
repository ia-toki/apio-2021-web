set -euo pipefail

# Pre-compilation hook script

# Currently empty
