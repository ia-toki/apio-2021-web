#include "jumps.h"

#include <vector>

void init(int, std::vector<int>) {

}

int minimum_jumps(int, int B, int C, int) {
  return C - B;
}
